#include<stdio.h>
#include<stdlib.h>
#define SIZE 15

int binarysearch(int array[], int key, int hi,int lo);

int main(void)
{
	int n[SIZE];
	int i,num,ans;
	
	printf("�п�J�Ʀr0��28:");
	scanf_s("%d", &num);

	printf("Subscript:\n");
	for (i = 0; i < SIZE; i++)
	{
		n[i] = 2 * i;
		printf("%4d ", i);
	}
	printf("\n");
	for (i = 0; i < SIZE; i++)
	{
		printf("%4d ", n[i]);
	}
	printf("\n");

	ans=binarysearch(n, num, SIZE-1,0);

	if (ans == -1)
	{
		printf("\n%d���s�b���}�C��\n", num);
	}
	else
	{
		printf("\n%d��m�b n[%d] \n", num,ans);
	}
	system("pause");
	return 0;
}

int binarysearch(int array[], int key, int hi, int lo)
{
	int mid;
	mid = (hi + lo) / 2;

	printf("\nlo=%d\n", lo);
	printf("hi=%d\n", hi);
	printf("mid=%d\n", mid);

	if (array[mid] == key)
	{
		return mid;
	}
	else if (mid== lo && mid==hi)
	{
		if (array[mid] == key)
		{
			return mid;
		}
		else
		{
			return -1;
		}
	}

	else if (array[mid] > key)
	{
		return  binarysearch(array, key, mid - 1, lo);
	}
	else if (array[mid] < key)
	{
		return  binarysearch(array, key, hi, mid + 1);
	}
	
}