#include<stdio.h>
#include<stdlib.h>
#define SIZE 5

int Maximum(int a[],int size);

int main(void)
{
	int a[5];

	printf("�п�J5�Ӽ�:");
	scanf_s("%d %d %d %d %d", &a[0],&a[1], &a[2], &a[3], &a[4]);
	
	printf("���ƦC���̤j�ƭȬ�:%d\n", Maximum(a,SIZE-1));
	system("pause");
	return 0;
}

int Maximum(int a[],int size)
{
	if (size == 1)
	{
		if (a [1] > a[0])
		{
			return a[1];
		}
		else
		{
			return a[0];
		}
	}
	else
	{
		if (a[size] > Maximum(a, size - 1))
		{
			return a[size];
		}
		else
		{
			return Maximum(a,size - 1);
		}
	}
	
}