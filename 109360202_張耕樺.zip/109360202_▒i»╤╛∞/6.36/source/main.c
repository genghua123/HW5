#include<stdio.h>
#include<stdlib.h>
#include<string.h>

void stringReverse(char n[],int lo,int hi);

int main()
{
	char a[100];
	int len;
	printf("�п�J�r��:");
	scanf("%s",a);

	
	printf("string is:%s\n", a);

	printf("stringReverse is:");
	len = strlen(a);
	stringReverse(a,0,len-1);
	
	printf("\n");
	
	system("pause");
	return 0;
}

void stringReverse(char n[], int lo, int hi)
{
	char *string = n;
	char temp;

	if (hi == (lo + 1))//����
	{
		temp = string[lo];
		string[lo] = string[hi];
		string[hi] = temp;

		printf("%s", string);
	}
	else if (hi == lo)//�_��
	{
		printf("%s", string);
	}
	else    
	{
		temp = string[lo];
		string[lo] = string[hi];
		string[hi] = temp;

		stringReverse(n, lo + 1, hi - 1);
	}
}